package com.wu.BugTracker.Controller;

import com.wu.BugTracker.DTO.BugRequest;
import com.wu.BugTracker.Entity.Bug;
import com.wu.BugTracker.Service.BugService;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bugs")
public class BugController {

    private final BugService bugService;

    public BugController(BugService bugService) {
        this.bugService = bugService;
    }

    // Create Bug
//    @PostMapping
//    public ResponseEntity<Bug> createBug(@RequestBody Bug bug) {
//        Bug saved = bugService.createBug(bug);
//        return ResponseEntity.ok(saved);
//    }
    
    @PostMapping
    @PreAuthorize("hasRole('tester')")
    public ResponseEntity<Bug> createBug(@Valid @RequestBody BugRequest request) {
        Bug saved = bugService.createBug(request);
        return ResponseEntity.ok(saved);
    }


    // Get Bug by ID
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('tester','manager','developer')")
    public ResponseEntity<Bug> getBugById(@PathVariable Long id) {
        Bug bug = bugService.getBugById(id);
        return ResponseEntity.ok(bug);
    }

    // Get All Bugs
    @GetMapping
    @PreAuthorize("hasAnyRole('tester','manager','developer')")
    public ResponseEntity<List<Bug>> getAllBugs() {
        List<Bug> bugs = bugService.getAllBugs();
        return ResponseEntity.ok(bugs);
    }

    // Update Bug
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('tester','developer')")
    public ResponseEntity<Bug> updateBug(@PathVariable Long id, @RequestBody Bug updated) {
        Bug saved = bugService.updateBug(id, updated);
        return ResponseEntity.ok(saved);
    }

    // Delete Bug
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('tester','manager')")
    public ResponseEntity<Void> deleteBug(@PathVariable Long id) {
        bugService.deleteBug(id);
        return ResponseEntity.noContent().build();
    }
}
