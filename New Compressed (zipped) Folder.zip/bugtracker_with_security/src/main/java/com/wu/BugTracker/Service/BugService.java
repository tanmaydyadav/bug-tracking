package com.wu.BugTracker.Service;

import com.wu.BugTracker.DTO.BugRequest;
import com.wu.BugTracker.Entity.Bug;
import com.wu.BugTracker.Entity.Employee;
import com.wu.BugTracker.Entity.Project;
import com.wu.BugTracker.Exception.NotFoundException;
import com.wu.BugTracker.Repository.BugRepository;
import com.wu.BugTracker.Repository.EmployeeRepository;
import com.wu.BugTracker.Repository.ProjectRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BugService {

    private final BugRepository bugRepository;
    private final ProjectRepository projectRepository;
    private final EmployeeRepository employeeRepository;

    public BugService(BugRepository bugRepository, ProjectRepository projectRepository, EmployeeRepository employeeRepository) {
        this.bugRepository = bugRepository;
        this.projectRepository = projectRepository;
        this.employeeRepository = employeeRepository;
    }

   
    
    

    // New one (DTO version)
    public Bug createBug(BugRequest request) {
        // Fetch project
        Project project = projectRepository.findById(request.getProjectId())
                .orElseThrow(() -> new NotFoundException("Project not found with id: " + request.getProjectId()));

        // Fetch reporter
        Employee reporter = employeeRepository.findById(request.getReporterId())
                .orElseThrow(() -> new NotFoundException("Reporter not found with id: " + request.getReporterId()));

        // Fetch assignee (optional)
        Employee assignee = null;
        if (request.getAssigneeId() != null) {
            assignee = employeeRepository.findById(request.getAssigneeId())
                    .orElseThrow(() -> new NotFoundException("Assignee not found with id: " + request.getAssigneeId()));
        }

        Bug bug = new Bug();
        bug.setTitle(request.getTitle());
        bug.setDescription(request.getDescription());
        bug.setPriority(request.getPriority());
        bug.setStatus(request.getStatus());
        bug.setProject(project);
        bug.setReporter(reporter);
        bug.setAssignee(assignee);

        return bugRepository.save(bug);
    }


    // Get Bug by ID
    public Bug getBugById(Long id) {
        return bugRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Bug not found with id: " + id));
    }

    // Get All Bugs
    public List<Bug> getAllBugs() {
        return bugRepository.findAll();
    }

    // Update Bug
    public Bug updateBug(Long id, Bug updated) {
        Bug existing = getBugById(id);

        existing.setTitle(updated.getTitle());
        existing.setDescription(updated.getDescription());
        existing.setPriority(updated.getPriority());
        existing.setStatus(updated.getStatus());

        if (updated.getProject() != null) {
            Long projectId = updated.getProject().getProjectId();
            Project project = projectRepository.findById(projectId)
                    .orElseThrow(() -> new NotFoundException("Project not found with id: " + projectId));
            existing.setProject(project);
        }

        if (updated.getReporter() != null) {
            Long reporterId = updated.getReporter().getUserId();
            Employee reporter = employeeRepository.findById(reporterId)
                    .orElseThrow(() -> new NotFoundException("Reporter not found with id: " + reporterId));
            existing.setReporter(reporter);
        }

        if (updated.getAssignee() != null && updated.getAssignee().getUserId() != null) {
            Long assigneeId = updated.getAssignee().getUserId();
            Employee assignee = employeeRepository.findById(assigneeId)
                    .orElseThrow(() -> new NotFoundException("Assignee not found with id: " + assigneeId));
            existing.setAssignee(assignee);
        }

        return bugRepository.save(existing);
    }

    // Delete Bug
    public void deleteBug(Long id) {
        Bug existing = getBugById(id);
        bugRepository.delete(existing);
    }
}
