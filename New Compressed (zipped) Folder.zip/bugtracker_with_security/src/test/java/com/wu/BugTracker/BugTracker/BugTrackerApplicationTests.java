package com.wu.BugTracker.BugTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BugTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
