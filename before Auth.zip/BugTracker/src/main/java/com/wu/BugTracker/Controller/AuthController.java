package com.wu.BugTracker.Controller;

import java.util.Collections;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wu.BugTracke.model.LoginCred;
import com.wu.BugTracke.security.JwtUtil;
import com.wu.BugTracker.Entity.Employee;
import com.wu.BugTracker.Repository.UserRepo;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/register")
    public Map<String, Object> registerHandler(@RequestBody Employee user) {
        // Encode password
    	System.out.println("entered the user");
        String encodedPass = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPass);
        user = userRepo.save(user);
        System.out.println("saved to user" + user.getUsername() + " " + user.getPassword());
        // Convert to UserDetails with ROLE_USER
        UserDetails userDetails = org.springframework.security.core.userdetails.User.builder()
                .username(user.getUsername())
                .password(user.getPassword())
                .roles("USER") // must match SecurityConfig hasRole("USER")
                .build();
        	System.out.println("userDEtails cretaed");
        // Generate JWT
        String token = jwtUtil.generateToken(userDetails);
        System.out.println("token generated" + token);
        return Collections.singletonMap("jwt-token", token);
    }


    @PostMapping("/login")
    public String loginHandler(
            @RequestBody LoginCred body
            ){
        try{
            UsernamePasswordAuthenticationToken authInputToken =
                    new UsernamePasswordAuthenticationToken(body.getUsername(), body.getPassword());
            authenticationManager.authenticate(authInputToken);

            return "Login successfully";
        } catch(AuthenticationException authExc){
            throw new RuntimeException("Invalid username/password.");
        }

    }

}